# run_goliveira_demo.ps1
# Cloth Demo Launcher

# Get the directory where this script is located
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Path to the executable relative to this script
$ExePath = Join-Path $ScriptDir "level1\level2\level3\level4\level5\level6\01_Transformations.exe"

# Check if executable exists
if (-not (Test-Path $ExePath)) {
    Write-Host "ERROR: Executable not found at:" -ForegroundColor Red
    Write-Host $ExePath -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

Write-Host "Launching Cloth Demo..." -ForegroundColor Green
Write-Host "Executable: $ExePath" -ForegroundColor Cyan
Write-Host ""

# Change to the executable's directory (important for relative paths!)
$ExeDir = Split-Path -Parent $ExePath
Push-Location $ExeDir

try {
    # Launch the executable
    & ".\01_Transformations.exe"
}
finally {
    # Return to original directory
    Pop-Location
}

Write-Host ""
Write-Host "Demo closed." -ForegroundColor Green